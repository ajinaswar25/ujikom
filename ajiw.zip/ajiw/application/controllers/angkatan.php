<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Angkatan extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_angkatan');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Angkatan';

        $data['angkatan'] = $this->Model_angkatan->getAllAngkatan();
        if( $this->input->post('keyword') ) {
            $data['angkatan'] = $this->Model_angkatan->Cariangkatan();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('angkatan/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Angkatan';

            $this->load->view('templates/header.php', $data);
            $this->load->view('angkatan/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_angkatan->Tambahangkatan();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('angkatan');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required');
        $data['angkatan'] = $this->Model_angkatan->getAngkatanById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Angkatan';

            $this->load->view('templates/header.php', $data);
            $this->load->view('angkatan/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_angkatan->Ubahangkatan();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('angkatan');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_angkatan->hapusAngkatan($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('angkatan');
    }
}
