<div class="container">
    <form action="" method="post">
        <legend>Tambah Data angkatan</legend>
        <div class="mb-3">
            <label for="angkatan" class="form-label">Nama angkatan</label>
            <input type="text" class="form-control" id="angkatan" name="angkatan" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('angkatan'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>