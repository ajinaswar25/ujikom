<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Angkatan</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $angkatan['id']; ?>">
            <label for="angkatan" class="form-label">Nama angkatan</label>
            <input type="text" class="form-control" id="angkatan" name="angkatan" value="<?= $angkatan['angkatan']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('angkatan'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>