<?php
class Model_angkatan extends CI_Model 
{
    public function getAllAngkatan()
    {
        return $query = $this->db->get('angkatan')->result_array();
    }

    public function Tambahangkatan()
    {
        $data = [
            "angkatan" => $this->input->post('angkatan', true)
        ];

        $this->db->insert('angkatan', $data);
    }

    public function Ubahangkatan()
    {
        $data = [
            "angkatan" => $this->input->post('angkatan', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('angkatan', $data);
    }

    public function hapusAngkatan($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('angkatan');
    }

    public function getAngkatanById($id)
    {
        return $this->db->get_where('angkatan', ['id' => $id])->row_array();
    }

    public function Cariangkatan()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('angkatan', $keyword);
        return $this->db->get('angkatan')->result_array();
    }
}

?>